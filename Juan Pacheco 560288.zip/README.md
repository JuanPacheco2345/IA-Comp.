# Chefs Table Project Solution
This repository is the Solution for Chef's Table Class Project. It contains all the finished files for the project.

## Boilerplate Repository
https://github.com/GeekwiseB2/chefs-table-bp

## Part 1 Solution
https://geekwiseb2.github.io/chefs-table-solution/demo-src/demo-part1.html

## Full Solution
https://geekwiseb2.github.io/chefs-table-solution/demo-src/demo-full-solution.html

## Extra Credit Solution
https://geekwiseb2.github.io/chefs-table-solution/
